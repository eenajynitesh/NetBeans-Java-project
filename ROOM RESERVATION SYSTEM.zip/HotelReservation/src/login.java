
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

 /*
 * login.java
 *
 * 

 */
/**
 *
 *
 */
import java.sql.*;
import javax.swing.*;

public class login extends javax.swing.JFrame {

    Connection conn = null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    public login() {
        initComponents();

        conn = LoginDB.ConnectDB();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txt_password = new javax.swing.JPasswordField();
        txt_username = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        LogInB = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setLayout(null);

        txt_password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_passwordActionPerformed(evt);
            }
        });
        jPanel1.add(txt_password);
        txt_password.setBounds(270, 290, 270, 20);
        jPanel1.add(txt_username);
        txt_username.setBounds(270, 260, 270, 20);

        jLabel2.setFont(new java.awt.Font("Cooper Std Black", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("Password");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(110, 290, 120, 22);

        jLabel1.setFont(new java.awt.Font("Cooper Std Black", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("ID");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(170, 260, 30, 19);

        jLabel3.setFont(new java.awt.Font("Forte", 1, 43)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 102));
        jLabel3.setText("ROOM RESERVATION SYSTEM");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(80, 10, 660, 48);

        LogInB.setFont(new java.awt.Font("Felix Titling", 1, 18)); // NOI18N
        LogInB.setForeground(new java.awt.Color(204, 0, 0));
        LogInB.setIcon(new javax.swing.ImageIcon(getClass().getResource("/103479-3d-glossy-green-orb-icon-business-thumbs-up2.png"))); // NOI18N
        LogInB.setContentAreaFilled(false);
        LogInB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LogInBActionPerformed(evt);
            }
        });
        jPanel1.add(LogInB);
        LogInB.setBounds(170, 320, 80, 80);

        jButton1.setFont(new java.awt.Font("Felix Titling", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 51, 51));
        jButton1.setIcon(new javax.swing.ImageIcon("E:\\hotel\\hotel\\refresh-icon.png")); // NOI18N
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(390, 330, 70, 70);

        jButton2.setFont(new java.awt.Font("Felix Titling", 1, 18)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/exit orig.png"))); // NOI18N
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(580, 330, 70, 70);

        jLabel4.setIcon(new javax.swing.ImageIcon("E:\\hotel\\hotel\\user-login.png")); // NOI18N
        jPanel1.add(jLabel4);
        jLabel4.setBounds(300, 70, 230, 240);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/hotel.gif"))); // NOI18N
        jPanel1.add(jLabel5);
        jLabel5.setBounds(-10, -10, 810, 440);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 792, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 420, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LogInBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LogInBActionPerformed
        // TODO add your handling code here:
        /*  
    }//GEN-LAST:event_LogInBActionPerformed
*/
        int sucess = 0;
        try {
            String sql = "SELECT * FROM tblogin";
            pst = conn.prepareStatement(sql);

            rs = pst.executeQuery(sql);

            String user = txt_username.getText();
            String pwd = new String(txt_password.getPassword());
            while (rs.next()) {
                String uname = rs.getString("username");
                String pass = rs.getString("password");

                if ((user.equals(uname)) && (pwd.equals(pass))) {
                    sucess = 1;

                    JOptionPane.showMessageDialog(null, "Sucess");
                    MainMenu a = new MainMenu();
                    a.setVisible(true);
                    this.dispose();
                } else {

                }
            }
        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, e);
        }
        if (sucess == 0) {
            JOptionPane.showMessageDialog(null, "Incorrect Credantials!!");
        }

    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        txt_username.setText(null);
        txt_password.setText(null);// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        System.exit(0); // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void txt_passwordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_passwordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_passwordActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LogInB;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField txt_password;
    private javax.swing.JTextField txt_username;
    // End of variables declaration//GEN-END:variables

}
